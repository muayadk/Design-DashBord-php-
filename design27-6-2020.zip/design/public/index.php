<?php  
define('ROOT',dirname(__DIR__));
include(ROOT.'/App/App.php');
   App::load();
	
      $p='home';
	 
	  if(isset($_GET['p']))
	  {
		  $p=$_GET['p'];
		  
     }
     else
    {
      $p='articles/add';

   
     }
	//include('config/DataBase.php');
 
   $p=explode('/',trim($p,'/'));
   var_dump($p);
   $action='index';

     if(isset($p[0]))
     {

      $controller='\App\Controller\\'.ucfirst($p[0]).'Controller';
     }

     if(isset($p[1]))
     {
      $action=$p[1];

     }

     $controller =new $controller();

     $controller->$action();

    //var_dump($controller->$action);

/*ob_start();
include(ROOT.'/App/Views/articles.php');

$content=ob_get_clean();

include(ROOT.'/App/Views/templete/defualt.php');*/