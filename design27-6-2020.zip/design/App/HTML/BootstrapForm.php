<?php 
namespace App\HTML;


class BootstrapForm extends Form{

  

    public function __constract( $data =array())
    {
        $this->data = $data;
    }


    protected function surround($html){

        return "<div class='form-group'> {$html } </div>";
    }

 

    public function input($name,$label){

        $label='<label>'.$label.'</label>';
        $input='<input type="text" name="'.$name.'" class="form-control"  value="'.$this->getValue($name).'">';
        
        return $this->surround($label.$input);
    }

    public function submit($name,$caption){

        
        return $this->surround('<button type="submit" class="btn btn-primary" name="'.$name.'">'.$caption.'</button>');
        
         
    }
}