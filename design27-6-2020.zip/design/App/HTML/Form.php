<?php 
 namespace App\HTML;

class Form{

    protected $data;
    protected $surround='p';

    public function __constract( $data =array())
    {
        $this->data = $data;
    }


    protected function surround($html){

        return "<{$this->surround}> {$html } </{$this->surround}>";
    }

    protected function getValue($index){

        return  isset($this->data[$index]) ? $this>data[$index] : null;
    }

    public function input($name,$label){

        $label='<label>'.$label.'</label>';
        $input='<input type="text" name="'.$name.'"  value="'.$this->getValue($name).'">';
        
        return $this->surround($label.$input);
    }

    public function submit($name,$caption){

        
        return $this->surround('<button type="submit" name="'.$name.'">'.$caption.'</button>');
        
         
    }
}