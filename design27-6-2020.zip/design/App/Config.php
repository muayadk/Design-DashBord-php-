<?php

namespace App;
 Class Config
 {
     private $settings=[];
     private static $_instance;
     
     public function __construct($config_file)
     {
         $this->settings= include($config_file);
     }
     
   


     public static function getInstance($config_file)
     {
         if(self::$_instance===null)
         {
       self::$_instance= new Config($config_file);
         }
       return self::$_instance;

    }


    public function get($key)
    {
       // var_dump($key);
       if(!isset( $this->settings[$key]))
       {
           return null;
       }
        return  $this->settings[$key];
    }


 }