<?php
 
 return  array(
     'host' => 'localhost',
     'username' => 'root',
     'password' => '',
     'db_name' => 'c_management'
    
 );

