<?php 
namespace App\Model;

class ArticleModel extends Model
{
		protected $table='articles';
		
		public function load()
		{
		//$pdo = new Database();
		//var_dump(\App::getDb());

			//return \App::getDb()->query('SELECT * FROM articles',__CLASS__); 
			return $this->query('SELECT 
				articles.id,
				articles.ref,
				articles.desig,
				articles.tav,
				units.unit,
				categories.category,
				suppliers.name as supplier_name

				FROM articles,suppliers,units,categories

				WHERE articles.supplier_id = suppliers.id
				AND articles.category_id = categories.id
				AND articles.unit_id = units.id
				
				'); 
		}

		public function show($id)
		{



		}


}