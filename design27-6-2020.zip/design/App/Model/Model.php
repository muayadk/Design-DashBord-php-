<?php 
 namespace App\Model;

use App\Database;
 class Model{

    protected $db;
    protected $table;
 
    public function  __construct(Database $db)
    {
        $this->db=$db;
        //var_dump(get_class($this));
    }

    public function create($fields){
        //var_dump($fields);
        $sql_pairs=[];
        $attributes=[];
        foreach($fields as $k => $v){
            $sql_pairs[]= "$k =   ?";
            $attributes[]=$v;
        }
        $sql_parts=implode(',', $sql_pairs);
        /*'ref'=>$_POST['ref'],
        'desig'=>$_POST['desig'],
        'category_id'=>$_POST['category'],
        'unit_id'=>$_POST['unit'],
        'tav'=>$_POST['tav'],
        'supplier_id '=>$_POST['text_info_id'],
        'thumb '=>$_FILES['thumb']['name'],
        'created_by '=>1,
        'updated__by '=>1*/

        $this->query("INSERT INTO {$this->table} SET $sql_parts ", $attributes);
      
    }

  
    public function update($id,$fields){
        
    }

    public function delete($id){
        
    }
    
    public function search($id,$fileds=null){
        
    }

    public function query($statement,$attributes= null ,$one = false ){
       // var_dump(get_class($this));
        //die();
        if($attributes)
        {
            return $this->db->prepare($statement,
            $attributes,
            $one,
            str_replace('Model','Entity',get_class($this)));
       
         }
       else
       {
        return $this->db->query(
            $statement,
            $one,
            str_replace('Model','Entity',get_class($this))
           );
        }
       
    }

 }