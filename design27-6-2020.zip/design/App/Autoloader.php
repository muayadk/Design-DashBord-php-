<?php 
  namespace App;
   class Autoloader
    {
      
      public static function autoload($class)
      {
        include(ROOT.'/'.$class.'.php');
       // var_dump($class);
      }

      public static function register(){
        spl_autoload_register(array(__CLASS__,'autoload'));
      }
    
    }