<?php 
namespace App;
use \PDO;
class Database{
	
    //  
    private $host;
    private $db_name;
   private $username;
    private $password;
    public $con;

    public function __construct($db_name,$host='localhost',$username='root',$password='')
    {
        $this->host=$host;
        $this->username=$username;
        $this->password=$password;
        $this->db_name=$db_name;
    }

    private function getPDO(){
       if( $this->con===null)
       {
        try{
           //$this->con = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
        $this->con = new PDO("mysql:host=" . $this->host ."; dbname=" . $this->db_name, $this->username, $this->password);
            $this->con->exec("set names utf8");
        }
        catch(PDOException $exception){
            echo "Connection error: " . $exception->getMessage();
        }
      }
  
        return $this->con;
    }


     // to return query
    public function query($statement, $one = false, $class = null)
        {
           
            $rs=$this->getPDO()->query($statement);
            if(
                strpos(strtolower($statement), 'insert') === 0 ||
                strpos(strtolower($statement), 'update') === 0 ||
                strpos(strtolower($statement), 'delete') ===  0 

            ){
                return $rs;

            }

            if($class === null) {
                $rs->setFetchMode(PDO::FETCH_OBJ);
            }

            else{
                $rs->setFetchMode(PDO::FETCH_CLASS,$class);
            }

            if($one){

                $data = $rs->fetch();
            }
            else{
                $data =  $rs->fetchAll();
            }


            return  $data;
        }
        

    public function prepare($statement,$attributes, $one = false, $class = null)
    {
        $rs = $this->getPDO()->prepare($statement);
        $rst = $rs->execute($attributes);
       // var_dump($rs);
        if(
            strpos(strtolower($statement), 'insert') === 0 ||
            strpos(strtolower($statement), 'update') === 0 ||
            strpos(strtolower($statement), 'delete') ===  0 

        ){
            return $rst;

        }

        if($class === null) {
            $rs->setFetchMode(PDO::FETCH_OBJ);
        }

        else{
            $rs->setFetchMode(PDO::FETCH_CLASS,$class);
        }

        if($one){

            $data = $rs->fetch();
        }
        else{
            $data =  $rs->fetchAll();
        }


        return  $data;
    }
}

?>