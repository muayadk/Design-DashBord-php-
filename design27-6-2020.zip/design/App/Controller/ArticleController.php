<?php
namespace App\Controller;

use App\Model\ArticleModel;
use App\HTML\ BootstrapForm;

class ArticleController extends Controller
    {

 
      public function __construct()
      {
            Parent::__construct();
            $this->loadModel('Article');
      }

     
     /* public function loadArticles()
      {
      //include(dirname(__FILE__).'/../Models/ArticlesModel.php');
      //$app =new \App();
      //$art=new ArticlesModel($app->getDb());
      
      $art=new ArticlesModel(\App::getInstance()->getDb());
      return $art->load();
      
      //include(dirname(__FILE__).'/../../views/articles.php');
      
      }*/

      public function index()
      {
            $articles= $this->Article->load();
            //$articles='';
           $this->render('articles/index',compact('articles'));
      }


      public function add()
      {
            //var_dump($_POST,$_FILES);
            if(!empty($_POST) && (!empty($_FILES))){
                  $this->Article->create([
                        'ref'=>$_POST['ref'],
                        'desig'=>$_POST['desig'],
                        'tav'=>$_POST['tav'],
                        'supplier_id '=>$_POST['supplier_id'],
                        'category_id'=>$_POST['category'],
                        'unit_id'=>$_POST['unit'],
                      
                        'thumb'=>$_FILES['thumb']['name'],
                        'created_by' =>1,
                        'updated_by'   =>1

                  ]);
            }
            $form= '';
            
           $this-> render('articles/add',compact('form'));
      }

      public function edit()
      {
            $form= new BootstrapForm($_POST);
            
           $this-> render('articles/edit',compact('form'));
      }

   

}