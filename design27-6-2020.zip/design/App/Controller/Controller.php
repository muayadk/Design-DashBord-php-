<?php

   namespace App\Controller;
  class Controller 
  {
      protected $viewPath;
      protected $template='default';

      public function  __construct()
      {
          $this->viewPath=ROOT.'/App/Views/';

      }
     
      protected function loadModel($model_name)
      {
         // var_dump($model_name);
          $this->$model_name=\App::getInstance()->getModel($model_name);
      }


      protected function render($view,$variables=[])
      {
        ob_start();
        extract($variables);
        include($this->viewPath . $view .'.php');
        
        $content=ob_get_clean();
        
        include($this->viewPath .'templete/'. $this->template .'.php');
      }


  }