<?php 
namespace App\Entity;

class ArticleEntity {
    
}