<!--header-->

<!DOCTYPE html>
<html>
<head>
<title>
</title>
<meta charset="utf-8">
 
<meta name="viewport" content="width=device-width, initial-scale=1">


<link rel="stylesheet" href="css/bootstrap.min.css">


<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap-glyphicons.css" rel="stylesheet">


<link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/responsive.css">

</head>

<body class="">
	<div  id="wrap" class="wrapper">

	<header class="main-header">

	<a href="#" class="logo">

	<span class="logo-mini"> <b>أ.د</b></span>
	 <span class="logo-lg"> <b>  ادارة مبيعات</b></span>

	</a>


	<nav class="navbar navbar-default navbar-static-top">	
	  <a href="#" id="btn-sidebar-collapse" class="sidebar-toggle"><span class="glyphicon glyphicon-menu-hamburger"></span></a>
	  
	   <ul class="nav navbar-nav navbar-notifs-top">
	   
	      <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
	          	
			    <span class="fa fa-globe"></span>
		            </a>
			   <ul class="dropdown-menu ">
				<li><a href="en">English</a></li>
			
			  </ul>
         </li>
	   
	   
	       <li class="dropdown">
	     
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
	     
                <img src="img/myimage/1.jpg" class="user-img-top" />
				<span class="hidden-xs user-name-top"><b> muayad </b></span>
        		 </a>
				 
				 <ul class="dropdown-menu dropdown-user"> 
				 <li class="user-header">  
				      <img src="img/myimage/1.jpg" class="img-circle" />
					  <p> <b>muayad esmail </b></p>
					   <p> <small> Eng</small></p>
				   </li>
				   
				   
				  <li class="user-body"> 
				    <div class="col-xs-4 text-center">
					<a href="#"> المشتريات</a>
					</div>
					
					 <div class="col-xs-4 text-center">
					<a href="#"> المبيعات</a>
					</div>
					
					 <div class="col-xs-4 text-center">
					<a href="#"> خيار</a>
					</div>
					</li>
				   <li class="user-footer">
				   <div class="pull-right">
				   <button class="btn btn-default" >البروفيل </button>
				   </div>
				     <div class="pull-left">
				   <button class="btn btn-default" > خروج</button>
				   </div>
				   </li>
				  </ul>	
				  
          </li>	

		  
        <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
	           <span class="glyphicon glyphicon-envelope"> </span>
			   <span class="label label-danger">12 </span>
		       
			  <ul class="dropdown-menu" >
				<li class="dropdown-header">لديك خمس رسائل</li>
				<li>
				   <ul class="list-group menu-msg">
					  <li class="list-group-item"> muayad </li>
					  <li class="list-group-item list-group-item-danger">Dapibus ac facilisis in</li>
					  <li class="list-group-item">Morbi leo risus</li>
					  <li class="list-group-item list-group-item-warning">Porta ac consectetur ac</li>
					  <li class="list-group-item">Vestibulum at eros</li>
				    </ul>
			    </li>
			 
					<li><a href="#">Something else here</a></li>
					<li role="separator" class="divider"></li>
					<li><a href="#">Separated link</a></li>
			  </ul>
        </li>
		
		    <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
	          	<span class="glyphicon glyphicon-flag"></span>
					   <span class="label label-danger">1</span>
		            </a>
			  <ul class="dropdown-menu ">
					<li><a href="#">Action</a></li>
					<li ><a href="#" >Another action</a></li>
					<li><a href="#">Something else here</a></li>
					<li role="separator" class="divider"></li>
					<li><a href="#">Separated link</a></li>
			  </ul>
         </li>
		 
		 
		     
		
		  
		
      </ul>
	
	</nav>
	

</header>
<!--end header-->

<!-- sidebar -->

<aside class="main-sidebar"> 
 
	 <section class="sidebar">
	 
		  <div class="gnav">
		  
			  <div class="gnav-header">
			   <a class="has-childs collapsed " role="button" data-toggle="collapse" href="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
			   <span class="glyphicon glyphicon-edit"></span>
				<span class="hidden-on-collapse"> المبيعات</span></a>
				</div>
			 <ul class="subnav collapse" id="collapseExample">
			 
			 <li >  <a href="#"> 
				  <span class="glyphicon glyphicon-edit"></span>
				  <span class="hidden-on-collapse"> الفواتير</span></a>
				</li>
				
				  <li >  <a href="#"> 
				  <span class="glyphicon glyphicon-edit"></span>
				  <span class="hidden-on-collapse"> الفواتير</span></a>
				  </li>
				
				  <li >  <a href="#"> 
				  <span class="glyphicon glyphicon-edit"></span>
				  <span class="hidden-on-collapse"> مرتجع المبيعات</span></a>
				 </li>
				
				  <li >  <a href="#"> 
				  <span class="glyphicon glyphicon-edit"></span>
				  <span class="hidden-on-collapse"> تقارير</span></a>
				</li>
				
				</ul>
			</div>
	  
	  
	      <div class="gnav">
		  
			  <div class="gnav-header">
			    <a href="#">
			  	  <span class="glyphicon glyphicon-flag"></span>
				  <span class="hidden-on-collapse">المبيعات</span></a>
               </div>
		  </div>	


        
		  <div class="gnav">
		  
			  <div class="gnav-header">
			   <a class="has-childs collapsed " role="button" data-toggle="collapse" href="#collapseExample1" aria-expanded="false" aria-controls="collapseExample1">
			   <span class="glyphicon glyphicon-edit"></span>
				<span class="hidden-on-collapse"> المشتريات</span></a>
				</div>
			 <ul class="subnav collapse" id="collapseExample1">
			 
			 <li >  <a href="#"> 
				  <span class="glyphicon glyphicon-edit"></span>
				  <span class="hidden-on-collapse"> الفواتير</span></a>
				</li>
				
				  <li >  <a href="#"> 
				  <span class="glyphicon glyphicon-edit"></span>
				  <span class="hidden-on-collapse"> ألمرتجعات</span></a>
				</li>
				
				  <li >  <a href="#"> 
				  <span class="glyphicon glyphicon-edit"></span>
				  <span class="hidden-on-collapse"> تقارير</span></a>
				</li>
				
				  <li >  <a href="#"> 
				  <span class="glyphicon glyphicon-edit"></span>
				  <span class="hidden-on-collapse"> الفواتير</span></a>
				</li>
				
				</ul>
			</div>
		  

	 </section>
 
 </aside>
<!-- end sidebar-->

<!-- view content start -->

			<div class="content-wrapper">
				
				<?=$content; ?>

			</div>




<!-- end view content start-->

<!-- footer-->


<footer class="main-footer">
 <p> &copy; حقوق الطبع محفوظة
 moayadabo0@gmail.com</p>

</footer>



</div>

		



<script src="js/jquery-3.4.1.min.js"> </script>
<script src="js/jquery-1.10.2.min.js"> </script>

<script src="js/jquery.min.js"> </script>
<script src="js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="css/DataTable.css">
<script src="js/jq.js"></script>
		<script src="js/DataTable.js"></script> 
		<script language="javascript">
				$(document).ready(function() {
					$("#mytable").DataTable();
				} );
		
		</script>	




 <script>
 
 
 
    $(document).ready(function() {
		
	 $('#btn-sidebar-collapse').click(function() {
	
		 if( $('body').hasClass('has-mini-sidebar') )
		 $('body').removeClass('has-mini-sidebar')
		 else
		 $('body').addClass('has-mini-sidebar')
	 });
	 
});


/*var x;
var a,b,c;

var table=["sami " ,10, "text" , 11.14];

for(var i=0; i<=table.length-1; i++)
{
	if(e==table[i])
	alert(" item :"+ table[i] +"e=10");
}*/


/*var e =document.getElementsByTagName("div");
for(var i=0; i<=e.length-1; i++)
alert(e[i].innerText);*/

  /*var first=document.querySelector(".gnav .gnav-header a span.hidden-on-collapse" ),
  
  all=document.querySelectorAll(".gnav .gnav-header a  span.hidden-on-collapse");
  
  alert(first.innerText);
  alert(all[0].innerText + '----'+ all[1].innerText);*/
  
  //jquery inmation method 
 /* $(document).ready(function () {
	  
	  $('header').click(function (){
		    //$('.logo').fadeOut('slow');
		   //$('.main-sidebar').hide(2000);
		 // $('.main-sidebar').toggle(2000);
		 // $('.logo').fadeIn('fast');
		  
	  });
	  
	  /*$('.content').animate({
		  'width':'300px',
		    'margin':'200px',
			'font-size':'100px',
		  
	  },1000,'linear');
  });*/
  
</script>

</body>
</html>
