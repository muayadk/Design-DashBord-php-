<h1>Edit</h1>

<form  method="post" action="" >

    <?=  $form->input('ref','كود المنتج'); ?>
    <?=  $form->input('desig',' اسم المنتج'); ?>
    <?=  $form->input('ref','كود المنتج'); ?>
    <?= $form->submit('save','حفظ');?>

</form>