<section class="content-header">
	 <span class="content-title"><i class="fa fa-home "> </i>  اضافة منتج جديد </span>
     </section>

<section class="content">
 <form method="post" name="form-article-add" id="form-article-add" enctype="multipart/form-data">

<div class="row form-add-top">
    <div class="col-sm-8 col-xs-12">
        <div class="box-infos-search">
                <section class="content-header box-infos-header">

                    <span class="content-title"><i class="fa fa-home "> </i>  المورد  </span>
                    <a href="#" class="btn btn-default btn-infos-search "  >
                        <i class="fa fa-search"></i>
                        <span class="hidden-xs hidden-sm"> بحث </span>
                    </a>
                </section>

                <div class="box-infos">
                    <input type="text" name="supplier_id" class="box-infos-id">
                    <h3 class="box-infos-name"> suplier 1</h3> 
                    <p class="box-infos-city"> Taiz 1 street </p>
                    <p class="box-address"> Taiz Almasbah </p>
                </div>

        </div>
        
    
    
      </div><!--end col-->
   
     <div class="col-sm-4 col-xs-12 text-center">
            <div class="box-infos-search">
                <section class="content-header box-infos-header">

                    <span class="content-title"><i class="fa fa-image "> </i>  الصورة  </span>
        
                </section>
            </div>

            <div class="box-infos">
                <img src="img/thumbs/articles/no-thumb.jpg" class="thumb-preview">
                <input type="file" name="thumb" class="form-control">
            </div>
       </div>
 </div>

    <div class="row">
        <div class="col-lg-12">
                <div class="form-group">
                    <div>
                    <label> رمز المنتح</lable>
                    </div>
                  <input type="text" name="ref" class="form-control">
              </div>

            <div class="form-group">
                <div>
                    <label class="label-control">  اسم المنتج</lable>
                </div>
                <input type="text" name="desig" class="form-control">
            </div>

            <div class="form-group">
                <div>
                    <label> الصنف</lable>
                </div>
                <select name="category" class="form-control">
                    <option value="1"> category1</option>
                    <option value="2"> category2</option>
                    <option value="3"> category3</option>
                </select>
            </div>

            <div class="form-group">
                    <div>
                        <label> الوحدة</lable>
                    </div>
                    <select name="unit" class="form-control">
                        <option value="1"> unit 1</option>
                        <option value="2"> unit 2</option>
                        <option value="3"> unit 3</option>
                    
                    </select>
            </div>

            <div class="form-group">
                <div>
                        <label> TVA(%)</lable>
                </div>
                <select name="tav" class="form-control">
                    <option value="20"> 20 %</option>
                    <option value="14"> 14 %</option>
                    <option value="7"> 7 %</option>
                </select>
            </div>
     </div><!--end  col-->
    
        
        <div class="col-lg-12 text-center">
          <button type="submit" id="btn-save-aricle" class="btn
            btn-primary">حفظ </button>
       </div>
 <div><!--end row-->
    <hr>

   

 </form>

 </section>