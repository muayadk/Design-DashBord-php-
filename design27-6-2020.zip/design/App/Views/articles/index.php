

<!--sidebar-->

<section class="content-header">
	 <span class="content-title"><i class="fa fa-home "> </i>  السلع  </span>
	 <ul class="header-btns">
         <li>  
			 <a href="#" class="btn btn-success">
			   <i class="fa fa-plus-circle"></i>
			   <span class="hidden-xs hidden-sm"> اضافة </span>
			</a>
		</li>
		<li> 
		<a href="#" class="btn btn-default" >
			   <i class="fa fa-search"></i>
			   <span class="hidden-xs hidden-sm"> بحث </span>
			</a>
         </li>

		<li>  
			 <a href="#" class="btn btn-default">
			   <i class="fa fa-print"></i>
			   <span class="hidden-xs hidden-sm"> طباعة </span>
			</a>
		</li>
		
     </ul>
	 </section>
 
 


<section class="content">
<div class="table-responsive">
 <table class="display rtl_table data-table table-striped table-hover" id="mytable">
	<thead>
		<tr>
		<th>الحدث</th>
		<th>الرقم</th>
		<th> الكود</th>
		<th>الاسم</th>
		<th>الوحدة</th>
		<th>الصنف</th>
		<th>TVA</th>
		<th>المورد</th>
		
		</tr>
	</thead>

	<tbody>
	<?php foreach($articles as $art)
        
		{
			echo"<tr>";
			echo"<td class='table-actions'> 
			<a href='#' class='btn btn-success btn-xs'>عرض </a>
			<a href='#' class='btn btn-warning btn-xs'> تعديل</a>
			<a href='#' class='btn btn-danger btn-xs'> حذف</a>
			</td>";
			echo"<td>".$art->id."</td>";
			echo"<td>".$art->ref."</td>";
			echo"<td>".$art->desig."</td>";
			echo"<td>".$art->unit."</td>";
			echo"<td>".$art->category."</td>";
			echo"<td>".$art->tav."</td>";
			echo"<td>".$art->supplier_name."</td>";
			echo"</tr>";
			
		}
		?>
	<tbody>
 </table>
</div>	

 </section>


		


