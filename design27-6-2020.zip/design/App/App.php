<?php 
     use App\Database;
   
 class App{
          
         private  $db;
         public static $_instance;

         
         public static function getInstance()
         {
            if(self::$_instance === null)
            {
               self::$_instance =new App();
            }
           
            return self::$_instance;
         }

        public static function load()
        {

            session_start();
           include(ROOT.'/App/Autoloader.php');

           \App\Autoloader::register();
         
         }

       
     public  function getDb()
      {
         if($this->db===null)
        {
           $config=\App\Config::getInstance(ROOT.'/App/config/config.php');
           //var_dump($config);
            $this->db =new Database($config->get('db_name'));
         }
            return $this->db;
     }

     // to load model request
     public function getModel($name)
     {
        $model= '\App\Model\\'.ucfirst($name).'Model';
       return  new $model($this->getDb());

     }

      }